package com.toh;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Align;

public class TOH_Main extends ApplicationAdapter {
	Stage estado;
	Button boton1,boton2,boton3;
	SpriteBatch batch;
	Texture img;
	Skin eso;

	@Override
	public void create() {
		batch = new SpriteBatch();
		img = new Texture("badlogic.jpg");

	}

	@Override
	public void render() {
		eso = new Skin(Gdx.files.internal("glassy-ui.json"));
		estado = new Stage();
		Table tabla = new Table();
		estado.addActor(tabla);
		Label titulo= new Label("Tower of Heaven",eso);
		titulo.setPosition(300,450);
		titulo.setSize(10,10);
		titulo.setAlignment(Align.center);

		boton1 = new TextButton("come caca",eso,"small");
		boton1.setSize(50,20);
        boton1.setPosition(300,350);

		boton2 = new TextButton("come verga",eso,"small");
		boton2.setSize(50,20);
		boton2.setPosition(300,250);

		boton3 = new TextButton("come mierda",eso,"small");
		boton3.setSize(50,20);
		boton3.setPosition(300,150);

		tabla.addActor(titulo);
		tabla.addActor(boton1);
		tabla.addActor(boton2);
		tabla.addActor(boton3);
		estado.act();
		estado.draw();

	}

	@Override
	public void dispose() {
		batch.dispose();
		img.dispose();
		estado.dispose();
	}


}

